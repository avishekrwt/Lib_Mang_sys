<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin_LMS</title>
    <link rel="stylesheet" type="text/css" href="../bootstrap-5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        #main_content {
            padding: 30px;
            background-color: #f8f9fa;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .navbar-nav .nav-item .nav-link {
            color: #fff;
            transition: color 0.3s;
        }
        .navbar-nav .nav-item .nav-link:hover {
            color: #d1d1d1;
        }
        .hero-section {
            background: linear-gradient(120deg, #3498db, #8e44ad);
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.2rem;
        }
        .hero-section .btn {
            background-color: #f39c12;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        .hero-section .btn:hover {
            background-color: #e67e22;
        }
        .info-list i {
            color: #3498db;
            margin-right: 10px;
        }
    </style>
    <script type="text/javascript">
  		function alertMsg(){
  			alert("Book added successfully...");
  			window.location.href = "admin_dashboard.php";
  		}
  	</script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="admin_dashboard.php">Library Management System (LMS)</a>
        <span class="navbar-text text-white"><strong>Welcome: <?php echo $_SESSION['name']; ?></strong></span>
        <span class="navbar-text text-white"><strong>Email: <?php echo $_SESSION['email']; ?></strong></span>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    My Profile
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="view_profile.php">View Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="hero-section">
    <div class="container">
        <h1>LMS Dashboard</h1>
        <p>Journey into Knowledge and Resources through Our LMS Dashboard</p>
        <a href="#main_content" class="btn">Get Started</a>
    </div>
</div>
<br>
<marquee>This is a Learning Management System - mini project created by <b>Abhishek Rawat</b> Roll no <b>2118102</b> </marquee>

<!-- admin main navbar -->
<nav class="navbar navbar-expand-lg" style="background: linear-gradient(135deg, #e3f2fd, #a1c4fd); box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
    <div class="container-fluid">
        <ul class="nav navbar-nav mx-auto">
            <li class="nav-item">
                <a class="nav-link" href="admin_dashboard.php" style="color: #0d6efd; margin-left: 50px ;font-weight: bold; transition: color 0.3s;">Dashboard</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" style="color: #0d6efd; margin-left: 50px ; font-weight: bold; transition: color 0.3s;">Books</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="add_book.php">Add New Book</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="manage_book.php">Manage Books</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" style="color: #0d6efd; margin-left: 50px ; font-weight: bold; transition: color 0.3s;">Category</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="add_cat.php">Add New Category</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="manage_cat.php">Manage Category</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="issue_book.php" style="color: #0d6efd; margin-left: 50px ; font-weight: bold; transition: color 0.3s;">Issue Book</a>
            </li>
        </ul>
    </div>
</nav>
<br>

<!-- Manage-book section -->
<center><h4>Manage Books</h4><br></center>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<table class="table table-bordered table-hover">
					<thead>
						<tr>
							<th>Name</th>
							<th>Author</th>
							<th>Category</th>
							<th>ISBN No.</th>
							<th>Price</th>
							<th>Action</th>
						</tr>
					</thead>
					<?php
						$connection = mysqli_connect("localhost","root","");
						$db = mysqli_select_db($connection,"lms");
						$query = "select * from books";
						$query_run = mysqli_query($connection,$query);
						while ($row = mysqli_fetch_assoc($query_run)){
							?>
							<tr>
								<td><?php echo $row['book_name'];?></td>
								<td><?php echo $row['author'];?></td>
								<td><?php echo $row['cat_id'];?></td>
								<td><?php echo $row['book_no'];?></td>
								<td><?php echo $row['book_price'];?></td>
								<td>
								<button class="btn"><a href="delete_book.php?bn=<?php echo $row['book_no'];?>">Delete</a></button></td>
							</tr>
							<?php
						}
					?>
				</table>
			</div>
			<div class="col-md-2"></div>
		</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybBogGzPpbu1N4gHDo+Gr/eydcrp5QK9xL2G7F6A4yoV4Q/lt" crossorigin="anonymous"></script>
<script src="../bootstrap-5.3.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
