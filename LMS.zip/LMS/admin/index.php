<?php
    session_start();
    if(isset($_POST['login'])){
        $connection = mysqli_connect("localhost","root","","lms");
        $query = "select * from admins where email = '$_POST[email]'";
        $query_run = mysqli_query($connection,$query);
        $login_successful = false;
        while ($row = mysqli_fetch_assoc($query_run)) {
            if($row['email'] == $_POST['email']){
                if($row['password'] == $_POST['password']){
                    $_SESSION['name'] =  $row['name'];
                    $_SESSION['email'] =  $row['email'];
                    $_SESSION['id'] =  $row['id'];
                    $login_successful = true;
                    break;
                }
                else{
                    $login_error = "Wrong Password !!";
                }
            }
        }
        mysqli_close($connection);
    
        if($login_successful){
            header("Location: admin_dashboard.php");
            exit; 
        }
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin_LMS</title>
    <link rel="stylesheet" type="text/css" href="../bootstrap-5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        #main_content {
            padding: 30px;
            background-color: #f8f9fa;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        #side_bar {
            background-color: #f8f9fa;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .navbar-nav .nav-item .nav-link {
            color: #fff;
            transition: color 0.3s;
        }
        .navbar-nav .nav-item .nav-link:hover {
            color: #d1d1d1;
        }
        form .form-group label {
            font-weight: bold;
        }
        form .form-group input, form .form-group textarea {
            border-radius: 4px;
        }
        .form-control::placeholder {
            color: #6c757d;
            opacity: 1;
        }
        .hero-section {
            background: linear-gradient(120deg, #3498db, #8e44ad);
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.2rem;
        }
        .hero-section .btn {
            background-color: #f39c12;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        .hero-section .btn:hover {
            background-color: #e67e22;
        }
        .info-list i {
            color: #3498db;
            margin-right: 10px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Library Management System (LMS)</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Admin Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../signup.php">Register</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">User Login</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="hero-section">
    <div class="container">
        <h1>Welcome to LMS</h1>
        <p>Your gateway to a world of knowledge and resources</p>
        <a href="#main_content" class="btn">Get Started</a>
    </div>
</div>
<br>
<marquee>This is a Learning Management System - mini project created by <b>Abhishek Rawat</b> Roll no <b>2118102</b> </marquee>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-4" id="side_bar">
            <h5>Library Information</h5>
            <ul class="info-list">
                <li><i class="fas fa-clock"></i> Opening: 8:00 AM</li>
                <li><i class="fas fa-clock"></i> Closing: 6:00 PM</li>
                <li><i class="fas fa-calendar-alt"></i> (Sunday Off)</li>
            </ul>
            <h5>What you can access here?</h5>
            <ul class="info-list">
                <li><i class="fas fa-book"></i> Issue Books</li>
                <li><i class="fas fa-wifi"></i> Free Wi-Fi</li>
                <li><i class="fas fa-newspaper"></i> Newspapers</li>
                <li><i class="fas fa-users"></i> Discussion Room</li>
                <li><i class="fas fa-laptop"></i> E-learning projects</li>
                <li><i class="fas fa-peace"></i> Peaceful Environment</li>
            </ul>
        </div>
        <div class="col-md-8" id="main_content">
            <h3 class="text-center"><u>Admin Login Form</u></h3>
            <form action="" method="post">
               
                <div class="form-group">
                    <label for="email">Email ID:</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>

                <button type="submit" name="login" class="btn btn-primary mt-3">Login</button>   
            </form>         
            <?php if(isset($login_error)): ?>
        <br><br><center><span style="color:red "><?php echo $login_error; ?></span></center>
    <?php endif; ?>
        </div>
    </div>
</div>
<script type="text/javascript" src="../bootstrap-5.3.3/js/jquery_latest.js"></script>
<script type="text/javascript" src="../bootstrap-5.3.3/js/bootstrap.min.js"></script>
<script src="../bootstrap-5.3.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
