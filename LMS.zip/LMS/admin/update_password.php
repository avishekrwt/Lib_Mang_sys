<?php
    session_start();
	$connection = mysqli_connect("localhost", "root", "","lms");
    $old_password_input = $_POST['old_password'];
    $new_password_input = $_POST['new_password'];
    $stored_password = "";

    // Fetch the stored password from the database
    $query = "SELECT password FROM admins WHERE email = '$_SESSION[email]'";
    $query_run = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($query_run)) {
        $stored_password = $row['password'];
    }

    // Check if the old password matches the stored password
    if ($stored_password == $old_password_input) {
        // Update the password in the database
        $query = "UPDATE admins SET password = '$new_password_input' WHERE email = '$_SESSION[email]'";
        $query_run = mysqli_query($connection, $query);
        ?>
        <script type="text/javascript">
            alert("Password updated successfully...");
            window.location.href = "admin_dashboard.php";
        </script>
        <?php
    } else {
        ?>
        <script type="text/javascript">
            alert("Incorrect current password...");
            window.location.href = "change_password.php";
        </script>
        <?php
    }
?>
