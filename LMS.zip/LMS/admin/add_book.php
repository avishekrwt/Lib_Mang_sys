<?php
    require("functions.php");
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin_LMS</title>
    <link rel="stylesheet" type="text/css" href="../bootstrap-5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        #main_content {
            padding: 30px;
            background-color: #f8f9fa;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .navbar-nav .nav-item .nav-link {
            color: #fff;
            transition: color 0.3s;
        }
        .navbar-nav .nav-item .nav-link:hover {
            color: #d1d1d1;
        }
        .hero-section {
            background: linear-gradient(120deg, #3498db, #8e44ad);
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.2rem;
        }
        .hero-section .btn {
            background-color: #f39c12;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        .hero-section .btn:hover {
            background-color: #e67e22;
        }
        .info-list i {
            color: #3498db;
            margin-right: 10px;
        }
    </style>
    <script type="text/javascript">
  		function alertMsg(){
  			alert("Book added successfully...");
  			window.location.href = "admin_dashboard.php";
  		}
  	</script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="admin_dashboard.php">Library Management System (LMS)</a>
        <span class="navbar-text text-white"><strong>Welcome: <?php echo $_SESSION['name']; ?></strong></span>
        <span class="navbar-text text-white"><strong>Email: <?php echo $_SESSION['email']; ?></strong></span>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    My Profile
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="view_profile.php">View Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="hero-section">
    <div class="container">
        <h1>LMS Dashboard</h1>
        <p>Journey into Knowledge and Resources through Our LMS Dashboard</p>
        <a href="#main_content" class="btn">Get Started</a>
    </div>
</div>
<br>
<marquee>This is a Learning Management System - mini project created by <b>Abhishek Rawat</b> Roll no <b>2118102</b> </marquee>

<!-- admin main navbar -->
<nav class="navbar navbar-expand-lg" style="background: linear-gradient(135deg, #e3f2fd, #a1c4fd); box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
    <div class="container-fluid">
        <ul class="nav navbar-nav mx-auto">
            <li class="nav-item">
                <a class="nav-link" href="admin_dashboard.php" style="color: #0d6efd; margin-left: 50px ;font-weight: bold; transition: color 0.3s;">Dashboard</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" style="color: #0d6efd; margin-left: 50px ; font-weight: bold; transition: color 0.3s;">Books</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="add_book.php">Add New Book</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="manage_book.php">Manage Books</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" style="color: #0d6efd; margin-left: 50px ; font-weight: bold; transition: color 0.3s;">Category</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="add_cat.php">Add New Category</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="manage_cat.php">Manage Category</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="issue_book.php" style="color: #0d6efd; margin-left: 50px ; font-weight: bold; transition: color 0.3s;">Issue Book</a>
            </li>
        </ul>
    </div>
</nav>
<br>

<!-- add-book section -->

<!-- add-book section -->
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                <div class="card-body">
                    <h4 class="card-title text-center"><b>Add a New Book</b></h4>
                    <form action="" method="post">
                        <div class="mb-3">
                            <label for="book_name" class="form-label">Book Name:</label>
                            <input type="text" name="book_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="book_author" class="form-label">Author Name:</label>
                            <input type="text" name="book_author" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="book_category" class="form-label">Category ID:</label>
                            <input type="text" name="book_category" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="book_no" class="form-label">Book Number:</label>
                            <input type="text" name="book_no" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="book_price" class="form-label">Book Price:</label>
                            <input type="text" name="book_price" class="form-control" required>
                        </div>
                        <button type="submit" name="add_book" class="btn btn-primary">Add Book</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybBogGzPpbu1N4gHDo+Gr/eydcrp5QK9xL2G7F6A4yoV4Q/lt" crossorigin="anonymous"></script>
<script src="../bootstrap-5.3.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
    if(isset($_POST['add_book'])) {
        $connection = mysqli_connect("localhost", "root", "", "lms");

       
        $book_name =  $_POST['book_name'];
        $book_category = (int) $_POST['book_category']; 
        $book_no = (int) $_POST['book_no']; 
        $book_price = (int) $_POST['book_price']; 
        $book_author =  $_POST['book_author'];

        $query = "INSERT INTO books (book_name, cat_id, book_no, book_price, author) 
                  VALUES ('$book_name', $book_category, $book_no, $book_price, '$book_author')";

        if (mysqli_query($connection, $query)) {
            exit();
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($connection);
        }

        mysqli_close($connection);
    }
?>
