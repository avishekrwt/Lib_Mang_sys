<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LMS</title>
    <link rel="stylesheet" type="text/css" href="bootstrap-5.3.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        #main_content {
            padding: 30px;
            background-color: #f8f9fa;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .navbar-nav .nav-item .nav-link {
            color: #fff;
            transition: color 0.3s;
        }
        .navbar-nav .nav-item .nav-link:hover {
            color: #d1d1d1;
        }
        .hero-section {
            background: linear-gradient(120deg, #3498db, #8e44ad);
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.2rem;
        }
        .hero-section .btn {
            background-color: #f39c12;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        .hero-section .btn:hover {
            background-color: #e67e22;
        }
        .info-list i {
            color: #3498db;
            margin-right: 10px;
        }
        .password-change-section {
            margin: 40px 0;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .password-change-section h4 {
            margin-bottom: 20px;
        }
        .password-change-section .form-group label {
            font-weight: bold;
        }
        .password-change-section .btn {
            background-color: #3498db;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        .password-change-section .btn:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="user_dashboard.php">Library Management System (LMS)</a>
        <span class="navbar-text text-white"><strong>Welcome: <?php echo $_SESSION['name']; ?></strong></span>
        <span class="navbar-text text-white"><strong>Email: <?php echo $_SESSION['email']; ?></strong></span>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    My Profile
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="view_profile.php">View Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="hero-section">
    <div class="container">
        <h1>LMS Dashboard</h1>
        <p>Journey into Knowledge and Resources through Our LMS Dashboard</p>
        <a href="#main_content" class="btn">Get Started</a>
    </div>
</div>

<br>
<marquee>This is a Learning Management System - mini project created by <b>Abhishek Rawat</b> Roll no <b>2118102</b> </marquee>

<div class="container">
    <div class="password-change-section">
        <center><h4>Change Student Password</h4></center>
        <form action="update_password.php" method="post">
            <div class="form-group">
                <label for="old_password">Enter Current Password:</label>
                <input type="password" class="form-control" id="old_password" name="old_password" required>
            </div>
            <div class="form-group">
                <label for="new_password">Enter New Password:</label>
                <input type="password" class="form-control" id="new_password" name="new_password" required>
            </div>
            <button type="submit" name="update" class="btn btn-primary mt-3">Update Password</button>
        </form>
    </div>
</div>

<script src="bootstrap-5.3.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>
