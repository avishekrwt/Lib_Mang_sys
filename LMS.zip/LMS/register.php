<?php
// Database connection
$connection = mysqli_connect("localhost", "root", "", "lms");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs to prevent SQL injection
    $name =  $_POST['name'];
    $email =  $_POST['email'];
    $password =  $_POST['password'];
    $mobile =  $_POST['mobile'];
    $address =  $_POST['address'];
    

    // SQL to insert data into the database
    $sql = "INSERT INTO users (name, email, password, mobile, address) VALUES ('$name', '$email', '$password', '$mobile', '$address')";
    
    // Execute the query and handle potential errors
    if (mysqli_query($connection, $sql)) {
        echo '<script type="text/javascript">
                alert("Registration successful...You may login now !!");
                window.location.href = "index.php";
              </script>';
    } else {
        // Check if the error is due to a duplicate entry
        if (mysqli_errno($connection) == 1062) {
            echo '<script type="text/javascript">
                    alert("Error: This mobile number is already registered.");
                    window.history.back();
                  </script>';
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connection);
        }
    }
}

// Close connection
mysqli_close($connection);
?>
